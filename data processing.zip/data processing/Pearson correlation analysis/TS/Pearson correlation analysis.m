% correlation analysis

load TStrain.mat
ys_data = TStrain;
[m,n] = size(ys_data);
for i = 2:n
    Y = ys_data(:,1);%因变量赋值给Y
    X = ys_data(:,i);%逐个将自变量赋值给X
    xs(1,i-1) = i;   %将相关性系数数组的第一行添加变量所在列位置标记1：p
    xs(2,i-1) = corr(X,Y,'type','Pearson');%逐个计算自变量与因变量间的Pearson相关性，保存至xs数组第二行
end
[m,n] = find(isnan(xs));
xs(:,n) = [];
[m_xs,id] = sort(abs(xs(2,:)),'descend'); %将变量间相关性系数按大到小降序排列，存储在m_xs矩阵中
mid_xs = xs(1,id);%将相关性系数降序排列的id存储于mid_xs中，即保存变量所在位置随着相关性系数降序排列保存。
need = find(abs(m_xs)>=0.2);
[i_x,i_y] = size(need);
for i = 1:i_y
    xyb(:,i+1) = ys_data(:,mid_xs(i));
end
xyb(:,1) = Y;
save xyb.mat





