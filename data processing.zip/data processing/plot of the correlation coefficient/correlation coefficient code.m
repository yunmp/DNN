clear
clc
etea=0.8; %阈值

% 加载数据
load Data.mat
%xlswrite('Data.xlsx',Data);
data=Data(:,1:22);
[N, D]=size(data);
% 求维度之间的相关系数
rho = corr(data, 'type','pearson');


% 绘制热图
string_name={'C','Si','Mn','P','S','Ni','Cr','Mo','Cu','Al','N','B','Nb','O','V','Ti','Sn','Sb','W','Co','TS','EL'};
xvalues = string_name;
yvalues = string_name;
h = heatmap(xvalues,yvalues,rho, 'FontSize',14, 'FontName','Times New Roman');
%h.Title = 'Correlation Coefficient';
colormap(jet)
saveas(gcf,sprintf('相关系数热图.jpg'),'bmp'); %保存图片
% 绝对值
rho=abs(rho);
rho_1=rho.*tril(ones(D,D),-1); %下三角
[row, col]=find(rho_1>etea); %找>etea的两个维度
[Num, ~]=size(row);
% A:存放相关系数>etea的两个维度及相关系数值
A=zeros(Num, 3);
for i=1:Num
    A(i,:)=[row(i), col(i), rho_1(row(i), col(i))];
    fprintf('强线性相关的两个维度是: 第%d个维度: %s与第%d个维度: %s, 两者的相关系数为：%f\n', row(i), string_name{row(i)}, col(i), string_name{col(i)}, rho_1(row(i), col(i)));   
end