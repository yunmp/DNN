clc
clear

load result.mat

%% test

t_sim1 = libsvmpredict(t_train, p_train, model);
t_sim2 = libsvmpredict(t_test , p_test , model);
%
T_sim1 = mapminmax('reverse', t_sim1, ps_output);
T_sim2 = mapminmax('reverse', t_sim2, ps_output);
T_sim1 = T_sim1';
T_sim2 = T_sim2';

%% plot
%
figure
plot(1: N, T_test, 'r-*', 1: N, T_sim2, 'b-o', 'LineWidth', 0.7)
legend('Actual value','Predicted value','FontSize',15,'FontName','Times New Roman')
xlabel('Number of prediction sample','FontSize',15,'FontName','Times New Roman','FontWeight','bold'); xticks(0:20:105);
ylabel('TS / MPa','FontSize',15,'FontName','Times New Roman','FontWeight','bold'); yticks(0:200:1400);
set(gca,'FontSize',15,'FontName','Times New Roman','FontWeight','bold')
xlim([0 105])
ylim([200 1400])
grid

figure 
plot(1:N,error2,'b*')
xlabel('Number of prediction sample','FontSize',15,'FontName','Times New Roman','FontWeight','bold'); xticks(0:20:105);
ylabel('TS / MPa','FontSize',15,'FontName','Times New Roman','FontWeight','bold'); yticks(-300:100:300);
set(gca,'FontSize',15,'FontName','Times New Roman','FontWeight','bold')
xlim([0 105])
ylim([-300 300])
grid

%fit
figure;
plotregression(T_train,T_sim1,'Training');
%
figure;
plotregression(T_test,T_sim2,'Test');
legend('Y=T','Fitting','Data','FontSize',16,'FontName','Times New Roman')
xlabel('Target','FontSize',18,'FontName','Times New Roman','FontWeight','bold'); xticks(400:100:1100);
ylabel('Output ~= 0.82*Target + 95','FontSize',18,'FontName','Times New Roman','FontWeight','bold'); yticks(400:100:1100);
set(gca,'FontSize',15,'FontName','Times New Roman','FontWeight','bold')
xlim([431 1090])
ylim([431 1090])

%error
figure
histogram(error2);
xlabel('Prediction error of SVR / MPa','FontSize',18,'FontName','Times New Roman','FontWeight','bold')
ylabel('Relative frequency / %','FontSize',18,'FontName','Times New Roman','FontWeight','bold')
set(gca,'FontSize',16,'FontName','Times New Roman','FontWeight','bold')
grid







