clc
clear

load result.mat

%% test

t_sim1 = svmpredict(t_train, p_train, model);
t_sim2 = svmpredict(t_test , p_test , model);
%
T_sim1 = mapminmax('reverse', t_sim1, ps_output);
T_sim2 = mapminmax('reverse', t_sim2, ps_output);
T_sim1 = T_sim1';
T_sim2 = T_sim2';

%% plot
%
figure
plot(1: N, T_test, 'r-*', 1: N, T_sim2, 'b-o', 'LineWidth', 0.7)
legend('Actual value','Predicted value','FontSize',16,'FontName','Times New Roman','FontWeight','bold')
xlabel('Number of prediction sample','FontSize',18,'FontName','Times New Roman','FontWeight','bold'); xticks(0:20:105);
ylabel('EL / %','FontSize',18,'FontName','Times New Roman','FontWeight','bold'); yticks(0:20:100);
set(gca,'FontSize',18,'FontName','Times New Roman','FontWeight','bold')
xlim([0 105])
ylim([0 100])
grid

figure 
plot(1:N,error2,'b*')
xlabel('Number of prediction sample','FontSize',15,'FontName','Times New Roman','FontWeight','bold'); xticks(0:20:105);
ylabel('EL / %','FontSize',15,'FontName','Times New Roman','FontWeight','bold'); yticks(-30:10:30);
set(gca,'FontSize',15,'FontName','Times New Roman','FontWeight','bold')
xlim([0 105])
ylim([-30 30])
grid

%fit
figure;
plotregression(T_train,T_sim1,'Training');
%
figure;
plotregression(T_test,T_sim2,'Test');
legend('Y=T','Fitting','Data','FontSize',16,'FontName','Times New Roman')
xlabel('Target','FontSize',18,'FontName','Times New Roman','FontWeight','bold'); xticks(10:10:80);
ylabel('Output ~= 0.9*Target + 3.2','FontSize',18,'FontName','Times New Roman','FontWeight','bold'); yticks(10:10:80);
set(gca,'FontSize',15,'FontName','Times New Roman','FontWeight','bold')
xlim([16 71])
ylim([16 71])
grid

%error
figure
histogram(error2);
xlabel('Prediction error of SVR / %','FontSize',18,'FontName','Times New Roman','FontWeight','bold')
ylabel('Relative frequency / %','FontSize',18,'FontName','Times New Roman','FontWeight','bold')
set(gca,'FontSize',16,'FontName','Times New Roman','FontWeight','bold')
grid







