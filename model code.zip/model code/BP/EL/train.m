clc
clear
%rng(1); %1是随机种子，随机种子固定，则每次的训练的结果永远固定
%% load data

load xyb.mat
datastd = std(xyb);
xyb(:,isnan(datastd)) = [];
n = size(xyb,1);
temp = randperm(n);
disp(temp(1:n));
numn = fix(0.8*n);
%% 
% train set
P_train = xyb(temp(1:numn),2:end)';
T_train = xyb(temp(1:numn),1)';
M = size(P_train, 2);
% test set
P_test = xyb(temp(numn+1:end),2:end)';
T_test = xyb(temp(numn+1:end),1)';
N = size(P_test,2);

%
[p_train, ps_input] = mapminmax(P_train,0,1); 
[t_train, ps_output] = mapminmax(T_train,0,1); 
p_test = mapminmax('apply',P_test,ps_input); 

%% build model
%
net = newff(p_train,t_train,[9,12],{'purelin'});


%train parameters
net.trainParam.epochs = 1000; 
net.trainParam.goal = 1e-4;
net.trainParam.lr = 0.001; %learning rate

%% train
net = train(net,p_train,t_train); 
% save my_bp net;
% save p_test p_test;
% save T_test T_test;
% save p_train p_train;
% save t_train t_train; 
% save ps_output ps_output;
% save W1;
% save W2;
% save B1;
% save B2; 


%% test
t_sim1 = sim(net,p_train);
t_sim2 = sim(net,p_test); 
%
T_sim1 = mapminmax('reverse',t_sim1,ps_output); 
T_sim2 = mapminmax('reverse',t_sim2,ps_output); 
%T_sim1 = T_sim1';
%T_sim2 = T_sim2';

%% evaluate
%analyzeNetwork(net)
% 
error1 = T_sim1 - T_train ;
error2 = T_sim2 - T_test ;
% train
SSE1=sum(error1.^2);                           
MAE1=sum(abs(error1))/M ;                   
MBE1 = sum(error1)./ M ;
MSE1=error1*error1'/M ;                     
RMSE1=sqrt(sum((error1.^2)./ M));      
MAPE1=mean(abs(error1./T_train));         
r1=corrcoef(T_train,T_sim1);    
R1=r1(1,2);
 
% test
SSE2=sum(error2.^2);                           
MAE2=sum(abs(error2))/N ;                   
MBE2 = sum(error2) ./ N ;
MSE2=error2*error2'/N ;                     
RMSE2=sqrt(sum((error2.^2)./ N));        
MAPE2=mean(abs(error2./T_test));        
r2=corrcoef(T_test,T_sim2);   
R2=r2(1,2);


a = max(error2);
b = min(error2);
c = mean(abs(error2));
d = std(error2);
e = mse(error2);
y = mean(T_test);
RR = 1-sum((error2).^2) / sum((T_test - y).^2);



result = [T_test' T_sim2' error2' P_test'];
save result.mat





