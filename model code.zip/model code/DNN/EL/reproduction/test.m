clc
clear

load result.mat

%% test

t_sim1 = sim(net,p_train);
t_sim2 = sim(net,p_test); 
%
T_sim1 = mapminmax('reverse',t_sim1,ps_output); 
T_sim2 = mapminmax('reverse',t_sim2,ps_output); 
T_sim1 = T_sim1';
T_sim2 = T_sim2';

%% evaluate
% 
% 
error1 = T_sim1 - T_train ;
error2 = T_sim2 - T_test ;
% train
SSE1=sum(error1.^2);                           
MAE1=sum(abs(error1))/M ;                   
MBE1 = sum(error1)./ M ;
MSE1=error1*error1'/M ;                      
RMSE1=sqrt(sum((error1.^2)./ M));       
MAPE1=mean(abs(error1./T_train));         
r1=corrcoef(T_train,T_sim1);    
R1=r1(1,2);
 
% test
SSE2=sum(error2.^2);                            
MAE2=sum(abs(error2))/N ;                  
MBE2 = sum(error2) ./ N ;
MSE2=error2*error2'/N ;                     
RMSE2=sqrt(sum((error2.^2)./ N));        
MAPE2=mean(abs(error2./T_test));        
r2=corrcoef(T_test,T_sim2);    
R2=r2(1,2);


a = max(error2);
b = min(error2);
c = mean(abs(error2));
d = std(error2);
e = mse(error2);
y = mean(T_test);
RR = 1-sum((error2).^2) / sum((T_test - y).^2);

%% plot
%
figure
plot(1: N, T_test, 'r-*', 1: N, T_sim2, 'b-o', 'LineWidth', 0.7)
legend('Actual value','Predicted value','FontSize',16,'FontName','Times New Roman','FontWeight','bold')
xlabel('Number of prediction sample','FontSize',18,'FontName','Times New Roman','FontWeight','bold'); xticks(0:20:105);
ylabel('EL / %','FontSize',18,'FontName','Times New Roman','FontWeight','bold'); yticks(0:20:100);
set(gca,'FontSize',18,'FontName','Times New Roman','FontWeight','bold')
xlim([0 105])
ylim([0 100])
grid

figure 
plot(1:N,error2,'b*')
xlabel('Number of prediction sample','FontSize',15,'FontName','Times New Roman','FontWeight','bold'); xticks(0:20:105);
ylabel('EL / %','FontSize',15,'FontName','Times New Roman','FontWeight','bold'); yticks(-30:10:30);
set(gca,'FontSize',15,'FontName','Times New Roman','FontWeight','bold')
xlim([0 105])
ylim([-30 30])
grid

%
figure;
plotregression(T_train,T_sim1,'Training');
%
figure;
plotregression(T_test,T_sim2,'Test');
legend('Y=T','Fitting','Data','FontSize',16,'FontName','Times New Roman')
xlabel('Target','FontSize',18,'FontName','Times New Roman','FontWeight','bold'); xticks(10:10:80);
ylabel('Output ~= 0.92*Target + 3','FontSize',18,'FontName','Times New Roman','FontWeight','bold'); yticks(10:10:80);
set(gca,'FontSize',15,'FontName','Times New Roman','FontWeight','bold')
xlim([16 71])
ylim([16 71])
grid


%error
figure
histogram(error2);
xlabel('Prediction error of DNN / %','FontSize',18,'FontName','Times New Roman','FontWeight','bold')
ylabel('Relative frequency / %','FontSize',18,'FontName','Times New Roman','FontWeight','bold')
set(gca,'FontSize',16,'FontName','Times New Roman','FontWeight','bold')
grid






